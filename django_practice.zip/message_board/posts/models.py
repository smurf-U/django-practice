from django.db import models


class Post(models.Model):
    text = models.TextField()
    text_a = models.TextField(default='')

    def __str__(self):
        return self.text[:50]
